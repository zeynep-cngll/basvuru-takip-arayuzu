const searchInput = document.getElementById('searchInput');
const statusPills = document.querySelectorAll('.status-pill');
const prioritySelect = document.getElementById('prioritySelect');
const rows = document.querySelectorAll('tbody tr');
const resetFiltersBtn = document.getElementById('resetFiltersBtn');
const tabs = document.querySelectorAll('.tab');

let activeStatus = 'Tümü';
let activeTab = 'tum'; // tum | aktif | beklemede

function applyFilters() {
    const searchText = (searchInput.value || '').toLowerCase().trim();
    const selectedPriority = prioritySelect.value || 'Hepsi';

    rows.forEach(row => {
        const companyName = row.querySelector('.company-name')?.textContent.toLowerCase() || '';
        const roleName = row.querySelector('.company-role')?.textContent.toLowerCase() || '';
        const statusText = row.querySelector('.status-chip')?.textContent || '';
        const priorityText = row.querySelector('.priority-pill')?.textContent || '';

        const matchesSearch =
            !searchText ||
            companyName.includes(searchText) ||
            roleName.includes(searchText);

        const matchesStatus =
            activeStatus === 'Tümü' ||
            statusText.includes(activeStatus);

        const matchesPriority =
            selectedPriority === 'Hepsi' ||
            priorityText.includes(selectedPriority);

        // Tab bazlı filtre:
        let matchesTab = true;
        const statusLower = statusText.toLowerCase();

        if (activeTab === 'aktif') {
            // Aktif süreç: olumsuz olmayan ve "Teklif alındı" dışındaki süreçler
            const isRejected = statusLower.includes('olumsuz');
            const isOffer = statusLower.includes('teklif');
            matchesTab = !isRejected && !isOffer;
        } else if (activeTab === 'beklemede') {
            // Beklemede: henüz mülakat/teklif olmayan, başvuruldu veya incelemede
            const isApplied = statusLower.includes('başvuruldu');
            const isReview = statusLower.includes('incelemede');
            matchesTab = isApplied || isReview;
        }

        const visible = matchesSearch && matchesStatus && matchesPriority && matchesTab;
        row.style.display = visible ? '' : 'none';
    });
}

// Arama
if (searchInput) {
    searchInput.addEventListener('input', applyFilters);
}

// Durum pill tıklama
statusPills.forEach(pill => {
    pill.addEventListener('click', () => {
        statusPills.forEach(p => p.classList.remove('active'));
        pill.classList.add('active');
        activeStatus = pill.dataset.status || 'Tümü';
        applyFilters();
    });
});

// Öncelik select
if (prioritySelect) {
    prioritySelect.addEventListener('change', applyFilters);
}

// Filtre sıfırlama
if (resetFiltersBtn) {
    resetFiltersBtn.addEventListener('click', () => {
        if (searchInput) searchInput.value = '';
        if (prioritySelect) prioritySelect.value = 'Hepsi';
        activeStatus = 'Tümü';
        activeTab = 'tum';
        statusPills.forEach(p => {
            p.classList.toggle('active', p.dataset.status === 'Tümü');
        });
        tabs.forEach(t => {
            t.classList.toggle('active', t.dataset.tab === 'tum');
        });
        applyFilters();
    });
}

// Sekmeler
tabs.forEach(tab => {
    tab.addEventListener('click', () => {
        tabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        activeTab = tab.dataset.tab || 'tum';
        applyFilters();
    });
});

// Yeni başvuru formu
const tbody = document.querySelector('tbody');

const newAppBtn = document.getElementById('newAppBtn');
const formCard = document.getElementById('newAppForm');
const applicationForm = document.getElementById('applicationForm');
const cancelFormBtn = document.getElementById('cancelFormBtn');

if (newAppBtn && formCard) {
    newAppBtn.addEventListener('click', () => {
        formCard.classList.toggle('visible');
    });
}

if (cancelFormBtn && formCard && applicationForm) {
    cancelFormBtn.addEventListener('click', () => {
        formCard.classList.remove('visible');
        applicationForm.reset();
    });
}

if (applicationForm && tbody) {
    applicationForm.addEventListener('submit', (e) => {
        e.preventDefault();

        const company = document.getElementById('company').value.trim();
        const role = document.getElementById('role').value.trim();
        const status = document.getElementById('status').value;
        const priority = document.getElementById('priority').value;
        const location = document.getElementById('location').value.trim() || 'Bilinmiyor';
        const jobType = document.getElementById('jobType').value.trim() || 'Belirtilmedi';
        const appliedAt = document.getElementById('appliedAt').value || '';
        const updatedAt = document.getElementById('updatedAt').value || '';
        const notes = document.getElementById('notes').value.trim() || '-';

        if (!company || !role) return;

        let statusClass = 'status-applied';
        if (status.includes('İncelemede')) statusClass = 'status-review';
        if (status.includes('Mülakat')) statusClass = 'status-interview';
        if (status.includes('Teklif')) statusClass = 'status-offer';
        if (status.includes('Olumsuz')) statusClass = 'status-rejected';

        let priorityClass = '';
        if (priority === 'Yüksek') priorityClass = 'priority-high';
        else if (priority === 'Orta') priorityClass = 'priority-medium';

        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>
                <div class="company-cell">
                    <span class="company-name">${company}</span>
                    <span class="company-role">${role}</span>
                </div>
            </td>
            <td>
                <span class="status-chip ${statusClass}">
                    <span></span> ${status}
                </span>
            </td>
            <td>
                <span class="priority-pill ${priorityClass}">${priority}</span>
            </td>
            <td>
                <span class="tag-pill">${location}</span>
                <span class="tag-pill">${jobType}</span>
            </td>
            <td><span class="date-muted">${appliedAt || '-'}</span></td>
            <td><span class="date-muted">${updatedAt || '-'}</span></td>
            <td class="notes">${notes}</td>
        `;

        tbody.appendChild(tr);

        applicationForm.reset();
        formCard.classList.remove('visible');

        applyFilters();
    });
}
